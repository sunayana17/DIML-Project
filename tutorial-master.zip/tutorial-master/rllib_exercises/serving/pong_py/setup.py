from setuptools import setup, find_packages, Distribution

setup(name='pong_py',
      packages=find_packages())
